<?php
/**
 * @package    mod_webcams
 * @author     Joe
 */

defined('_JEXEC') or die;

JHtml::_('stylesheet', 'modules/mod_webcams/mod_webcams.css');
JHtml::_('bootstrap.modal');

$modId = 'webcam' . $module->id;
?>

<!-- BUTTON, DER DEN MODAL ÖFFNET -->
<div id="webcamintro<?php echo $module->id; ?>">
    <img
        src="<?php echo $params->get('introimg'); ?>"
        style="width:200px;"
        class="hover-shadow cursor mx-auto d-block"
        id="openModalBtn<?php echo $module->id; ?>"
        data-bs-toggle="modal"
        data-bs-target="#<?php echo $modId; ?>"
    />
</div>


<!-- MODAL -->
<div id="<?php echo $modId; ?>" class="modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">

        <!-- HIER KOMMEN SPÄTER DIE SLIDES REIN -->
        <div id="webcamSlidesContainer<?php echo $module->id; ?>"></div>

        <!-- Pfeile -->
        <a class="pr" onclick="plusSlides(-1)">&#10094;</a>
        <a class="nx" onclick="plusSlides(1)">&#10095;</a>

    </div>
  </div>
</div>


<script>
// ------------------------------------------------------------
// SLIDES WERDEN ERST GELADEN, WENN DER BUTTON GEKLICKT WIRD
// ------------------------------------------------------------
let slidesLoaded<?php echo $module->id; ?> = false;

document.getElementById('openModalBtn<?php echo $module->id; ?>')
    .addEventListener('click', function() {

        if (slidesLoaded<?php echo $module->id; ?>) return;

        let container = document.getElementById('webcamSlidesContainer<?php echo $module->id; ?>');

        // PHP baut hier erst jetzt das HTML!
        <?php foreach ($webcams as $cam): ?>
            container.innerHTML += `<?php echo addslashes(
                Troppmair\Module\Webcams\Site\Helper\WebcamsHelper::baueSliderHtml(
                    $cam['type'],
                    $cam['name'],
                    $cam['address']
                )
            ); ?>`;
        <?php endforeach; ?>

        slidesLoaded<?php echo $module->id; ?> = true;

        showSlides(slideIndex = 1);
});


// ------------------------------------------------------------
// SLIDER FUNKTIONEN (UNVERÄNDERT)
// ------------------------------------------------------------
var slideIndex = 1;

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("webcamSlides");
  if (slides.length === 0) return;

  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}

  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  slides[slideIndex-1].style.display = "block";
}
</script>
