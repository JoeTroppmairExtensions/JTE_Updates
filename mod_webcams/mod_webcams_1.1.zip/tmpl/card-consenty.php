<?php
/**
 * @package    mod_webcams
 * @tmpl-type  Template for BS-Cards incl. Consenty-JS
 * @author     Joe Troppmair <joe@troppmair.com>
 * @copyright  JoeTroppmairExtensions
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * @link       www.troppmair.com
 */

// No direct access to this file
defined('_JEXEC') or die;
JHtml::_('bootstrap.modal');

$modId = 'webcam' . $module->id;
?>

<!-- Button trigger modal -->
<div id="webcamintro<?php echo $module->id; ?>" class="">
 <div class="col">
  <div class="card">
   <div class="card-header bg-dark fs-5 text-white"><?php echo JText::_('MOD_WEBCAM_CARD_TITLE'); ?> <i class="bi bi-camera-video fs-4 float-end"></i></div>
    <template consenty-if="!webcams">
	 <div class="d-flex justify-content-center">
		 <div class="">
		  <img
			src="<?php echo $params->get('introimg'); ?>"
			style="opacity: 0.4;"
		  />
		 </div>
		 <div style="position: absolute; bottom: 0; /* transform: translate(0, -50%);*/">
		  <p class="text-center mx-2">
			<button type="button" class="btn btn-danger btn-lg" consenty-allow="webcams"><?php echo JText::_('CC_ALLOW_CONTENT'); ?></button>
		</p>
		<p class="mx-2">
			<a href="<?php echo JText::_('CC_GOTO_GPDRLINK'); ?>" class=""><?php echo JText::_('CC_GOTO_GPDR'); ?></a>
		</p>
		 </div>
	 </div>
    </template>
    <template consenty-if="webcams">
	 <div class="card-img-top-wrapper">
	  <img src="<?php echo $params->get('introimg'); ?>"
		  alt="webcams"
		  class="img-fluid hover-shadow cursor mx-auto d-block"
		  style="width:100%;"
	  />
	  <div class="card-body card-overlay">
	   <div class="card-content">
	    <p><?php echo JText::_('MOD_WEBCAM_CARD_CONTENT'); ?></p>
	    <p id="webcamintro<?php echo $module->id; ?>"><button class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#webcam<?php echo $module->id; ?>"><?php echo JText::_('MOD_WEBCAM_OPEN'); ?></button></p>
	   </div>
	  </div>
	 </div>
    </template>
  </div>   
 </div>
</div>

<template consenty-if="webcams">
<div id="<?php echo $modId; ?>" class="modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">

		<!--div class="mySlides"> 
		  <div class="modal-header">
			<h4>Ausgabe print_r</h4>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		  </div>
		  <div><?php #echo "<pre>"; print_r($result); echo "</pre>"; ?></div>
		</div>
		
	<!-- slides hier: -->
	<?php
		for ($i = 1; $i <= 10; $i++) {
			if ($params->get("cam_active_$i") == 1) {
				echo ${"webcam$i"};
			}
		}
	?>
	<!-- : slides bis hier -->
		

      <!--div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div-->
    
	<a class="pr" onclick="plusSlides(-1)">&#10094;</a>
	<a class="nx" onclick="plusSlides(1)">&#10095;</a>
	
	</div>
  </div>
</div>

<script>
	var slideIndex = 1;
	showSlides(slideIndex);

	function plusSlides(n) {
	  showSlides(slideIndex += n);
	}

	function currentSlide(n) {
	  showSlides(slideIndex = n);
	}

	function showSlides(n) {
	  var i;
	  var slides = document.getElementsByClassName("webcamSlides");
	  if (n > slides.length) {slideIndex = 1}
	  if (n < 1) {slideIndex = slides.length}
	  for (i = 0; i < slides.length; i++) {
		  slides[i].style.display = "none";
	  }
	  slides[slideIndex-1].style.display = "block";
	}
</script>
</template>