<?php
/**
 * @package    mod_webcams
 * @tmpl-type  
 * @author     Joe Troppmair <joe@troppmair.com>
 * @copyright  Joe Troppmair
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * @link       www.troppmair.com
 */

// No direct access to this file
defined('_JEXEC') or die;
JHtml::_('bootstrap.modal');

$modId = 'webcam' . $module->id;
?>

<!-- Button trigger modal -->
<template consenty-if="!webcams">
  <div id="webcamintro<?php echo $module->id; ?>" class="">
	<img
		src="<?php echo $params->get('introimg'); ?>"
		style="width:200px; opacity: 0.6;"
		class="hover-shadow mx-auto d-block"
	/>
	<button type="button" class="btn btn-warning btn-lg mx-auto d-block" consenty-allow="webcams" style="position: relative; bottom: 75px; ">Erlaube Externen Inhalt</button>
  </div>
</template>
<template consenty-if="webcams">
  <div id="webcamintro<?php echo $module->id; ?>" class="">
	<img
		src="<?php echo $params->get('introimg'); ?>"
		style="width:100%;"
		class="hover-shadow cursor mx-auto d-block"
		data-bs-toggle="modal"
		data-bs-target="#<?php echo $modId; ?>"
	/>
  </div>

<div id="<?php echo $modId; ?>" class="modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">

		<!--div class="mySlides"> 
		  <div class="modal-header">
			<h4>Ausgabe print_r</h4>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		  </div>
		  <div><?php #echo "<pre>"; print_r($result); echo "</pre>"; ?></div>
		</div>
		
	<!-- slides hier: -->
	<?php
		if($params->get('cam_active_1') == 1) { echo $webcam1; }
		if($params->get('cam_active_2') == 1) { echo $webcam2; }
		if($params->get('cam_active_3') == 1) { echo $webcam3; }
		if($params->get('cam_active_4') == 1) { echo $webcam4; }
		if($params->get('cam_active_5') == 1) { echo $webcam5; }
		if($params->get('cam_active_6') == 1) { echo $webcam6; }
		if($params->get('cam_active_7') == 1) { echo $webcam7; }
		if($params->get('cam_active_8') == 1) { echo $webcam8; }
		if($params->get('cam_active_9') == 1) { echo $webcam9; }
		if($params->get('cam_active_10') == 1) { echo $webcam10; }
	?>
	<!-- : slides bis hier -->
		

      <!--div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div-->
    
	<a class="pr" onclick="plusSlides(-1)">&#10094;</a>
	<a class="nx" onclick="plusSlides(1)">&#10095;</a>
	
	</div>
  </div>
</div>

<script>
	var slideIndex = 1;
	showSlides(slideIndex);

	function plusSlides(n) {
	  showSlides(slideIndex += n);
	}

	function currentSlide(n) {
	  showSlides(slideIndex = n);
	}

	function showSlides(n) {
	  var i;
	  var slides = document.getElementsByClassName("webcamSlides");
	  if (n > slides.length) {slideIndex = 1}
	  if (n < 1) {slideIndex = slides.length}
	  for (i = 0; i < slides.length; i++) {
		  slides[i].style.display = "none";
	  }
	  slides[slideIndex-1].style.display = "block";
	}
</script>
</template>