<?php
/**
 * @package    mod_webcams
 * @author     Joe
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();

$wa->useScript('bootstrap.modal');

$modId = 'webcam' . $module->id;
?>

<!-- BUTTON, DER DEN MODAL ÖFFNET -->
<div id="webcamintro<?php echo $module->id; ?>" class="">
   <div class="col"><?php echo Text::_('MOD_WEBCAM_CARD_TITLE'); ?> <i class="bi bi-camera-video fs-4 float-end"></i></div>
    <template consenty-if="!webcams">
	 <div class="d-flex justify-content-center">
		 <div class="">
		  <img
			src="<?php echo $params->get('introimg'); ?>"
			style="opacity: 0.4;"
		  />
		 </div>
		 <div style="position: absolute; bottom: 0; /* transform: translate(0, -50%);*/">
		  <p class="text-center mx-2">
			<button type="button" class="btn btn-danger btn-lg" consenty-allow="webcams"><?php echo Text::_('CC_ALLOW_CONTENT'); ?></button>
		</p>
		<p class="mx-2">
			<a href="<?php echo Text::_('CC_GOTO_GPDRLINK'); ?>" class=""><?php echo Text::_('CC_GOTO_GPDR'); ?></a>
		</p>
		 </div>
	 </div>
    </template>
    <template consenty-if="webcams">
	 <div class="col">
	  <a id="<?php echo $module->id; ?>" data-bs-toggle="modal" data-bs-target="#<?php echo $modId; ?>">
	  <img src="<?php echo $params->get('introimg'); ?>"
		  alt="webcams"
		  class="img-fluid hover-shadow cursor mx-auto d-block"
		  style="width:100%;"
	  />
	  <a>

	    <p><?php echo Text::_('MOD_WEBCAM_CARD_CONTENT'); ?></p>
	    <p id="<?php echo $module->id; ?>"><button class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#<?php echo $modId; ?>"><?php echo Text::_('MOD_WEBCAM_OPEN'); ?></button></p>
	 </div>
    </template>
  </div>   

<!-- MODAL -->
<template consenty-if="webcams">
<div id="<?php echo $modId; ?>" class="modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">

        <!-- HIER KOMMEN SPÄTER DIE SLIDES REIN -->
        <div id="webcamSlidesContainer<?php echo $module->id; ?>"></div>

        <!-- Pfeile -->
        <a class="pr" onclick="plusSlides(-1)">&#10094;</a>
        <a class="nx" onclick="plusSlides(1)">&#10095;</a>

    </div>
  </div>
</div>


<script>
// ------------------------------------------------------------
// SLIDES WERDEN ERST GELADEN, WENN DER BUTTON GEKLICKT WIRD
// ------------------------------------------------------------
let slidesLoaded<?php echo $module->id; ?> = false;

document.getElementById('<?php echo $module->id; ?>')
    .addEventListener('click', function() {

        if (slidesLoaded<?php echo $module->id; ?>) return;

        let container = document.getElementById('webcamSlidesContainer<?php echo $module->id; ?>');

        // PHP baut hier erst jetzt das HTML!
        <?php foreach ($webcams as $cam): ?>
            container.innerHTML += `<?php echo addslashes(
                Troppmair\Module\Webcams\Site\Helper\WebcamsHelper::baueSliderHtml(
                    $cam['type'],
                    $cam['name'],
                    $cam['address']
                )
            ); ?>`;
        <?php endforeach; ?>

        slidesLoaded<?php echo $module->id; ?> = true;

        showSlides(slideIndex = 1);
});


// ------------------------------------------------------------
// SLIDER FUNKTIONEN (UNVERÄNDERT)
// ------------------------------------------------------------
var slideIndex = 1;

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("webcamSlides");
  if (slides.length === 0) return;

  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}

  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  slides[slideIndex-1].style.display = "block";
}
</script>
</template>
