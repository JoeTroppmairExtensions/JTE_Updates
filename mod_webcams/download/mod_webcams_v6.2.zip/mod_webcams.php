<?php
/**
 * @package    mod_webcams
 * @author     Joe Troppmair
 * @version    6.1 - 20.09.2026
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;
use Troppmair\Module\Webcams\Site\Helper\WebcamsHelper;

// WebAssetManager und Registry holen
$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->getRegistry()->addRegistryFile('modules/mod_webcams/joomla.asset.json');

// Assets laden / aktivieren
#$wa->useScript('bootstrap.carousel');
$wa->useStyle('webcam.css');

// ------------------------------------------------------------
// WEBCAM PARAMETER SAMMELN (aber NOCH KEIN HTML ERZEUGEN!)
// ------------------------------------------------------------

$webcams = [];

for ($i = 1; $i <= 10; $i++) {
    if ($params->get("cam_active_$i") == 1) {
        $webcams[] = [
            'type'    => $params->get("cam_type_$i"),
            'name'    => $params->get("cam_name_$i"),
            'address' => $params->get("cam_address_$i")
        ];
    }
}

// Übergabe ans Template
$moduleLayoutData = [
    'webcams' => $webcams,
];

require ModuleHelper::getLayoutPath('mod_webcams', $params->get('layout', 'default'));
