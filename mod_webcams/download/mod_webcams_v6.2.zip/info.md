*==========================================================*
|                                                          |
|  (C) JoeTroppmairExtensions 2026       JJ TTTTTT EEEEEE  |
|                                        JJ   TT   EE      |
|      Joe Troppmair                     JJ   TT   EEEE    |
|      www.troppmair.com             JJ  JJ   TT   EE      |
|                                     JJJJ    TT   EEEEEE  |
|      MOD_WEBCAMS MODULE                                  |
|                                                          |
*==========================================================*


# Version 6.1 - 21.09.2026
  * Ueberarbeitung im Rahmen des Joomla!6 Systems
    - lauffaehig ohne Compat6
	- CSS & Bootstrap ueber WebAssetManager direkt integriert
	- Template-HTML-Overrides entfernt, weil im Modul entsprechend realisiert
	- Update-Server hinzugefuegt

# Version 6.2 - 24.09.2026
  * Update-Routine via script.php
	- bei Update werden Dateien, die nicht in der XML definiert sind, entfernt,
	  um den Code sauber zu halten
	- geschuetzte Dateien und Verzeichnisse moeglich, zB bereits definiert: 'tmpl/jte-entwicklung'
  *	Anpassen der XML:
    - Inline-Hilfe aktivieren ueber description="MOD_WEBCAMS_DESC_INTROIMG" in der XML
	- Testen der Sprachdateien und div. Anpassungen
