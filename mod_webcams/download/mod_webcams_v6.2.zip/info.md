```text
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█                                                          █
█  (C) JoeTroppmairExtensions 2026       ██ ██████ ██████  █
█                                        ██   ██   ██      █
█      Joe Troppmair                     ██   ██   █████   █
█      www.troppmair.com             ██  ██   ██   ██      █
█                                     ████    ██   ██████  █
█      MOD_WEBCAMS MODULE                                  █
█                                                          █
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
```

# Version 6.1 - 21.09.2026
  * Überarbeitung im Rahmen des Joomla!6 Systems
    - lauffähig ohne Compat6
	- CSS & Bootstrap über WebAssetManager direkt integriert
	- Template-HTML-Overrides entfernt, weil im Modul entsprechend realisiert
	- Update-Server hinzugefügt

# Version 6.2 - 24.09.2026
  * Update-Routine via script.php
	- bei Update werden Dateien, die nicht in der XML definiert sind, entfernt,
	- um den Code sauber zu halten
	- geschützte Dateien und Verzeichnisse möglich, zB bereits definiert: 'tmpl/jte-entwicklung'