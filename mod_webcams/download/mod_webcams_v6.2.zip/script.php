<?php

defined('_JEXEC') or die;

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;

return new class () implements InstallerScriptInterface
{
    /**
     * Dateien und Verzeichnisse, die bei Updates niemals
     * automatisch gelöscht oder verändert werden.
     *
     * Pfade sind relativ zum Erweiterungsverzeichnis.
     */
    private array $protected = [
        'testdatei.php',
        'tmpl/jte_entwicklung',
    ];

    /**
     * Installation.
     */
    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Update.
     */
    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Deinstallation.
     */
    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Vor Installation / Update / Deinstallation.
     */
    public function preflight(
        string $type,
        InstallerAdapter $adapter
    ): bool {
        /*
         * Nur bei einem Update bereinigen.
         */
        if ($type !== 'update') {
            return true;
        }

        $installer = $adapter->getParent();

        /*
         * Verzeichnis des neuen Installationspakets.
         */
        $source = $installer->getPath('source');

        /*
         * Bereits installiertes Erweiterungsverzeichnis.
         */
        $destination = $installer->getPath('extension_root');

        /*
         * Sicherheitsprüfung.
         */
        if (
            !is_dir($source) ||
            !is_dir($destination)
        ) {
            return true;
        }

        /*
         * Dateien des neuen Pakets ermitteln.
         */
        $newFiles = $this->getRelativeFiles($source);

        /*
         * Dateien der bisherigen Installation ermitteln.
         *
         * Geschützte Dateien und komplette geschützte
         * Verzeichnisbäume werden übersprungen.
         */
        $oldFiles = $this->getRelativeFiles(
            $destination,
            true
        );

        /*
         * Alte Dateien ermitteln, die im neuen Paket
         * nicht mehr vorhanden sind.
         */
        $obsoleteFiles = array_diff(
            $oldFiles,
            $newFiles
        );

        /*
         * Veraltete Dateien löschen.
         */
        foreach ($obsoleteFiles as $relativePath) {

            /*
             * Zusätzliche Schutzprüfung.
             */
            if ($this->isProtected($relativePath)) {
                continue;
            }

            $path = $destination . '/' . $relativePath;

            /*
             * Nur innerhalb des Erweiterungsverzeichnisses löschen.
             */
            if (
                !$this->isInsideDirectory(
                    $path,
                    $destination
                )
            ) {
                continue;
            }

            if (
                is_file($path) ||
                is_link($path)
            ) {
                @unlink($path);
            }
        }

        /*
         * Leere Verzeichnisse entfernen.
         *
         * Geschützte Verzeichnisse bleiben vollständig erhalten.
         */
        $this->removeEmptyDirectories(
            $destination
        );

        return true;
    }

    /**
     * Nach Installation / Update / Deinstallation.
     */
    public function postflight(
        string $type,
        InstallerAdapter $adapter
    ): bool {
        return true;
    }

    /**
     * Ermittelt sämtliche Dateien innerhalb eines Verzeichnisses.
     *
     * Bei $skipProtected = true werden geschützte Dateien
     * und komplette geschützte Verzeichnisbäume übersprungen.
     */
    private function getRelativeFiles(
        string $directory,
        bool $skipProtected = false
    ): array {
        $files = [];

        $realDirectory = realpath($directory);

        if (
            $realDirectory === false ||
            !is_dir($realDirectory)
        ) {
            return $files;
        }

        $realDirectory = rtrim(
            $realDirectory,
            DIRECTORY_SEPARATOR
        );

        try {

            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(
                    $realDirectory,
                    FilesystemIterator::SKIP_DOTS
                ),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($iterator as $file) {

                if (
                    !$file->isFile() &&
                    !$file->isLink()
                ) {
                    continue;
                }

                $fullPath = $file->getPathname();

                $relativePath = substr(
                    $fullPath,
                    strlen($realDirectory) + 1
                );

                /*
                 * Windows "\" → "/"
                 */
                $relativePath = str_replace(
                    DIRECTORY_SEPARATOR,
                    '/',
                    $relativePath
                );

                /*
                 * Geschützte Dateien und Verzeichnisse
                 * vollständig ignorieren.
                 */
                if (
                    $skipProtected &&
                    $this->isProtected($relativePath)
                ) {
                    continue;
                }

                $files[] = $relativePath;
            }

        } catch (\Throwable $e) {

            /*
             * Bei einem Fehler keine automatische Bereinigung.
             */
            return [];
        }

        return $files;
    }

    /**
     * Prüft, ob ein relativer Pfad geschützt ist.
     *
     * Ein geschütztes Verzeichnis schützt automatisch
     * seinen gesamten Inhalt.
     */
    private function isProtected(
        string $relativePath
    ): bool {
        $relativePath = trim(
            str_replace(
                '\\',
                '/',
                $relativePath
            ),
            '/'
        );

        foreach ($this->protected as $protected) {

            $protected = trim(
                str_replace(
                    '\\',
                    '/',
                    $protected
                ),
                '/'
            );

            /*
             * Exakte Übereinstimmung.
             */
            if ($relativePath === $protected) {
                return true;
            }

            /*
             * Datei oder Unterverzeichnis innerhalb
             * eines geschützten Verzeichnisses.
             */
            if (
                str_starts_with(
                    $relativePath,
                    $protected . '/'
                )
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Entfernt leere Verzeichnisse rekursiv.
     *
     * Geschützte Verzeichnisse werden vollständig
     * übersprungen.
     */
    private function removeEmptyDirectories(
        string $directory,
        string $baseDirectory = ''
    ): void {
        if (!is_dir($directory)) {
            return;
        }

        /*
         * Basisverzeichnis beim ersten Aufruf festlegen.
         */
        if ($baseDirectory === '') {

            $baseDirectory = realpath($directory);

            if ($baseDirectory === false) {
                return;
            }

            $baseDirectory = rtrim(
                $baseDirectory,
                DIRECTORY_SEPARATOR
            );
        }

        $items = scandir($directory);

        if ($items === false) {
            return;
        }

        foreach ($items as $item) {

            if (
                $item === '.' ||
                $item === '..'
            ) {
                continue;
            }

            $path = $directory . '/' . $item;

            /*
             * Nur echte Verzeichnisse bearbeiten.
             */
            if (
                !is_dir($path) ||
                is_link($path)
            ) {
                continue;
            }

            /*
             * Relativen Pfad ermitteln.
             */
            $relativePath = substr(
                $path,
                strlen($baseDirectory) + 1
            );

            $relativePath = str_replace(
                DIRECTORY_SEPARATOR,
                '/',
                $relativePath
            );

            /*
             * Geschützte Verzeichnisse komplett überspringen.
             *
             * Dadurch wird auch kein Unterverzeichnis
             * innerhalb eines geschützten Ordners entfernt.
             */
            if ($this->isProtected($relativePath)) {
                continue;
            }

            /*
             * Unterverzeichnisse bearbeiten.
             */
            $this->removeEmptyDirectories(
                $path,
                $baseDirectory
            );

            /*
             * Prüfen, ob das Verzeichnis jetzt leer ist.
             */
            $contents = scandir($path);

            if (
                $contents !== false &&
                count($contents) === 2
            ) {
                @rmdir($path);
            }
        }
    }

    /**
     * Sicherheitsprüfung:
     *
     * Der zu löschende Pfad muss sich innerhalb
     * des Erweiterungsverzeichnisses befinden.
     */
    private function isInsideDirectory(
        string $path,
        string $directory
    ): bool {
        $realDirectory = realpath($directory);

        if ($realDirectory === false) {
            return false;
        }

        $realDirectory = rtrim(
            $realDirectory,
            DIRECTORY_SEPARATOR
        ) . DIRECTORY_SEPARATOR;

        /*
         * Existierender Pfad.
         */
        $realPath = realpath($path);

        if ($realPath !== false) {

            return str_starts_with(
                $realPath . DIRECTORY_SEPARATOR,
                $realDirectory
            );
        }

        /*
         * Falls der Pfad nicht aufgelöst werden kann,
         * normalisierte Variante prüfen.
         */
        $normalizedPath = str_replace(
            ['/', '\\'],
            DIRECTORY_SEPARATOR,
            $path
        );

        return str_starts_with(
            $normalizedPath,
            $realDirectory
        );
    }
};