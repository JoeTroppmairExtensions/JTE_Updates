<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_foo
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Troppmair\Module\Webcams\Site\Helper;

// No direct access to this file
defined('_JEXEC') or die;

/**
 * Helper for mod_webcams
 *
 * @since  4.0
 */
class WebcamsHelper {
	/**
	 * Retrieve foo test
	 *
	 * @param   Registry        $params  The module parameters
	 * @param   CMSApplication  $app     The application
	 *
	 * @return  array
	 */
	#public static function holeTextAlsTest()
	#{
	#	return ' Das ist der Text, der beim Aufruf der HelperKlasse verwendet wird!';
		
	#}
	public static function getWebcamsParams(&$params) {
		return $params;
	}
	
	
	/**
	 * Definiere die Ausgabevarianten:
	 * 
	 *
	 */
	public static function baueSliderHtml($cam_type, $cam_name, $cam_address) {

		// Standardausgaben
		$div_start = "<div class='webcamSlides'>
						<div class='modal-header'>
							<h4>". $cam_name ."</h4>
							<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
						</div>";
		$div_img = "<img src='" . $cam_address . "' /></div>";
		$div_feratel = "<div class='iframecontainer'>
							<iframe src='https://webtv.feratel.com/webtv/?pg=5EB12424-7C2D-428A-BEFF-0C9140CD772F&design=v5&cam=". $cam_address ."&c1=0' 
									class='iframe-feratel' 
									allowfullscreen='yes' 
									scrolling='no' 
							/></iframe></div></div>";
		$div_panomax = "<video src='". $cam_address ."' autoplay controls style='height: auto; width: 100%' /></video>
						</div>";
						
		// Switch
		switch ($cam_type) {
			case "img":
				$ausgabeHtml = $div_start . $div_img;
			break;
			case "feratel":
				$ausgabeHtml = $div_start . $div_feratel;
			break;
			case "panomax":
				$ausgabeHtml = $div_start . $div_panomax;
			break;
		}
		return $ausgabeHtml;
	}

}