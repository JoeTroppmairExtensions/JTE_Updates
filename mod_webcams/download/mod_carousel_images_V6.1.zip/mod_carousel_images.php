<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_carousel_images
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;

// WebAssetManager und Registry holen
$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->getRegistry()->addRegistryFile('modules/mod_carousel_images/joomla.asset.json');

// Assets laden / aktivieren
$wa->useScript('bootstrap.carousel');
$wa->useStyle('standard.css');

use Troppmair\Module\CarouselImages\Site\Helper\CarouselImagesHelper;

$link   = $params->get('link');
$folder = CarouselImagesHelper::getFolder($params);
$images = CarouselImagesHelper::getImages($params, $folder);
$image  = CarouselImagesHelper::getRandomImage($params, $images);

require ModuleHelper::getLayoutPath('mod_carousel_images', $params->get('layout', 'default'));
?>