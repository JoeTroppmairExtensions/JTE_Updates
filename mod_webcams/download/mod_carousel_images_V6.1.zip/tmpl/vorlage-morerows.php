<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_carousel_images
 *
 * Service from: https://gist.github.com/EdgarPateno/fd118fb55334859b9462a9ac4adc4216
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

defined('_JEXEC') or die;
JHtml::_('bootstrap.carousel');

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

if (!count($images)) {
    echo Text::_('MOD_RANDOM_IMAGE_NO_IMAGES');

    return;
}
$sliderID = $params->get('sliderID', 'default');
$sliderStyle = $params->get('sliderStyle', 'default');
$sliderNavControl = $params->get('sliderNavControl', 'default');
$sliderIndicator = $params->get('sliderIndicator', 'default');
$sliderDarkControl = $params->get('sliderDarkControl', 'default');
$sliderCaptionControl = $params->get('sliderCaptionControl', 'default');

// Debug
#echo $folder;
# echo $type;
# echo $params->get('type', 'jpg');
#	<h3><?php echo JText::_('CAPTION_TITLE_' .strtoupper(pathinfo($item->name), PATHINFO_FILENAME). '.' .$params->get('type', 'jpg'). '');
?>

<style>

@media (max-width: 767px) {
	.carousel-inner .carousel-item > div {
		display: none;
	}
	.carousel-inner .carousel-item > div:first-child {
		display: block;
	}
}

	.carousel-inner .carousel-item.active,
	.carousel-inner .carousel-item-next,
	.carousel-inner .carousel-item-prev {
		display: flex;
}

/* medium and up screens */
@media (min-width: 768px) {

	.carousel-inner .carousel-item-end.active,
	.carousel-inner .carousel-item-next {
		transform: translateX(25%);
	}

	.carousel-inner .carousel-item-start.active, 
	.carousel-inner .carousel-item-prev {
		transform: translateX(-25%);
	}
}

.carousel-inner .carousel-item-end,
.carousel-inner .carousel-item-start { 
	transform: translateX(0);
}

.carousel-control-prev, .carousel-control-next{
    background-color: #999;
    width: 6vh;
    height: 6vh;
    border-radius: 50%;
    top: 50%;
    transform: translateY(-50%);
}

</style>

<div class="container text-center my-3">
		<div class="row mx-auto my-auto justify-content-center">
			<div id="recipeCarousel" class="carousel slide" data-bs-ride="carousel">
				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 1</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten_rasen.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 2</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten_voll.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 3</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/grill_tischtennis.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 4</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten_rasen.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 5</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/grill_tischtennis.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 6</div>
							</div>
						</div>
					</div>
				</div>
				<a class="carousel-control-prev" href="#recipeCarousel" role="button" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#recipeCarousel" role="button" data-bs-slide="next">
					<span class="visually-hidden">Next</span>
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
				</a>
			</div>
		</div>		
	</div>

<script>
let items = document.querySelectorAll('.carousel .carousel-item')

		items.forEach((el) => {
			const minPerSlide = 4
			let next = el.nextElementSibling
			for (var i=1; i<minPerSlide; i++) {
				if (!next) {
            // wrap carousel by using first child
            next = items[0]
        }
        let cloneChild = next.cloneNode(true)
        el.appendChild(cloneChild.children[0])
        next = next.nextElementSibling
    }
})
</script>