<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_carousel_images
 *
 * Service from: https://gist.github.com/EdgarPateno/fd118fb55334859b9462a9ac4adc4216
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

defined('_JEXEC') or die;
JHtml::_('bootstrap.carousel');

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

if (!count($images)) {
    echo Text::_('MOD_RANDOM_IMAGE_NO_IMAGES');

    return;
}
$sliderID = $params->get('sliderID', 'default');
$sliderStyle = $params->get('sliderStyle', 'default');
$sliderNavControl = $params->get('sliderNavControl', 'default');
$sliderIndicator = $params->get('sliderIndicator', 'default');
$sliderDarkControl = $params->get('sliderDarkControl', 'default');
$sliderCaptionControl = $params->get('sliderCaptionControl', 'default');

// Debug
#echo $folder;
# echo $type;
# echo $params->get('type', 'jpg');
#	<h3><?php echo JText::_('CAPTION_TITLE_' .strtoupper(pathinfo($item->name), PATHINFO_FILENAME). '.' .$params->get('type', 'jpg'). '');
?>



<!--div class="container text-center my-3">
		<div class="row mx-auto my-auto justify-content-center">
			<div id="recipeCarousel" class="carousel slide" data-bs-ride="carousel">
				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 1</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 2</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 3</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 4</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 5</div>
							</div>
						</div>
					</div>
					<div class="carousel-item">
						<div class="col-md-3">
							<div class="card">
								<div class="card-img">
									<img src="images/slider/garten/garten.jpg" class="img-fluid">
								</div>
								<div class="card-img-overlay">Slide 6</div>
							</div>
						</div>
					</div>
				</div>
				<a class="carousel-control-prev bg-transparent w-aut" href="#recipeCarousel" role="button" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				</a>
				<a class="carousel-control-next bg-transparent w-aut" href="#recipeCarousel" role="button" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
				</a>
			</div>
		</div>		
	</div-->



<div class="row mx-auto my-4 justify-content-center">
<div id="<?php echo $sliderID; ?>" class="carousel <?php echo $sliderStyle; ?> <?php echo $sliderDarkControl; ?>" data-bs-ride="carousel">
	
	<div id="multiple" class="carousel-inner">
		<?php for ($i = 0, $n = count($images); $i < $n; $i ++) : ?>
			<?php $item = $images[$i]; ?>
				<?php if ($i == 0){?>
					<div class="carousel-item <?php echo 'active';  ?>" >
						<div class="col-12 col-md-6 col-lg-4">
						<div class="mx-1"><?php echo HTMLHelper::_('image', $item->folder . '/' . htmlspecialchars($item->name, ENT_COMPAT, 'UTF-8'), ''); ?></div>
							<?php if ($sliderCaptionControl == 1) : ?>
								<div class="carousel-caption d-none d-md-block">
									<h3><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_HX'); ?></h3>
									<p><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_TX'); ?></p>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php } else { ?>
					<div class="carousel-item" >
						<div class="col-12 col-md-6 col-lg-4">
							<div class="mx-1"><?php echo HTMLHelper::_('image', $item->folder . '/' . htmlspecialchars($item->name, ENT_COMPAT, 'UTF-8'), ''); ?></div>
							<?php if ($n > 1 && $sliderCaptionControl == 1) : ?>
								<div class="carousel-caption d-none d-md-block">								
									<h3><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_HX'); ?></h3>
									<p><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_TX'); ?></p>
								</div>
							<?php endif; ?>
							
						</div>
					</div>
				<?php } ?>
		<?php endfor; ?>
	</div>

	<?php if ($n > 1 && $sliderIndicator == 1) : ?>
		<div class="carousel-indicators">
		<?php for ($i = 0, $n = count($images); $i < $n; $i ++) : ?>
			<?php if ($i == 0){?>
			<button type="button" data-bs-target="#<?php echo $sliderID; ?>" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
			<?php } else { ?>
			<button type="button" data-bs-target="#<?php echo $sliderID; ?>" data-bs-slide-to="<?php echo $i; ?>" aria-label="Slide 2"></button>
			<?php } ?>
		<?php endfor; ?>
		</div>
	<?php endif; ?>	

	<?php if ($n > 1 && $sliderNavControl == 1) : ?>
		<button class="carousel-control-prev" type="button" data-bs-target="#<?php echo $sliderID; ?>" data-bs-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</button>
		<button class="carousel-control-next" type="button" data-bs-target="#<?php echo $sliderID; ?>" data-bs-slide="next">
			<span class="sr-only">Next</span>
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
		</button>
	<?php endif; ?>
</div>
</div>

<script>
let items = document.querySelectorAll('.carousel .carousel-item')

		items.forEach((el) => {
			const minPerSlide = 2
			let next = el.nextElementSibling
			for (var i=1; i<minPerSlide; i++) {
				if (!next) {
            // wrap carousel by using first child
            next = items[0]
        }
        let cloneChild = next.cloneNode(true)
        el.appendChild(cloneChild.children[0])
        next = next.nextElementSibling
    }
})
</script>