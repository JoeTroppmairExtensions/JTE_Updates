<?php
/**
 * @package    mod_webcams
 * @author     Joe Troppmair
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Troppmair\Module\Webcams\Site\Helper\WebcamsHelper;

// ------------------------------------------------------------
// WEBCAM PARAMETER SAMMELN (aber NOCH KEIN HTML ERZEUGEN!)
// ------------------------------------------------------------

$webcams = [];

for ($i = 1; $i <= 10; $i++) {
    if ($params->get("cam_active_$i") == 1) {
        $webcams[] = [
            'type'    => $params->get("cam_type_$i"),
            'name'    => $params->get("cam_name_$i"),
            'address' => $params->get("cam_address_$i")
        ];
    }
}

// Übergabe ans Template
$moduleLayoutData = [
    'webcams' => $webcams,
];

require ModuleHelper::getLayoutPath('mod_webcams', $params->get('layout', 'default'));
