<?php
/*▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█															█
█	(C) JoeTroppmairExtensions 2026		██ ██████ ██████	█
█										██   ██   ██		█
█		Joe Troppmair					██   ██   █████		█
█		www.troppmair.com			██	██   ██   ██     	█
█									 ████    ██   ██████	█
█															█
█															█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄*/

defined('_JEXEC') or die;
use Joomla\CMS\Factory;

// Template-Parameter holen und als Variablen setzen
$fluidgrid = $this->params->get('fluidgrid');
$footercolgrid = $this->params->get('footercolgrid');
$leftcolgrid = ($this->countModules('left') == 0) ? 0 :
	$this->params->get('leftColumnWidth', 3);
$rightcolgrid = ($this->countModules('right') == 0) ? 0 :
	$this->params->get('rightColumnWidth', 3);
		
// Anzeige Meta-Generator Joomla ausschalten:
$this->setGenerator(null);

// Zuladen von CSS und JS nach J!6-Vorgaben:
$doc = Factory::getApplication()->getDocument();
$wa  = $doc->getWebAssetManager();

$wa->useStyle('bootstrap');
$wa->useStyle('bootstrap-icons');
$wa->useStyle('template-css');

if ($this->params->get('template-js')) {
	$wa->useScript('template-js');
}
if ($this->params->get('consenty-js')) {
	$wa->useScript('consenty');
}
if ($this->params->get('floatpanel-js')) {
		$wa->useScript('float-panel');
}


// auf Startseite ist eine eigene CSS notwendig:
#$app = JFactory::getApplication();
#$menu = $app->getMenu()->getActive()->id;
#	if ($menu == "101") :
	if ( $this->countModules('startslider') ) :
		#$wa->useStyle('start-css');
		$wa->useScript('start-js');
	endif;

// lade das GANZE Bootstrap Framework aus '/media/jui' wenn gewünscht:
/*if ($this->params->get('bootstrapframework')) {
	JHtml::_('bootstrap.framework');
}
*/


?>
