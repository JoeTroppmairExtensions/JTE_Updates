<?php
 /**
  * Joe Troppmair ohne jQuery!
  * https://stackoverflow.com/questions/69534538/bootstrap-5-modal-open-on-page-load
  * ohne Button
	<!-- Button trigger modal
		<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#<?php echo $modId; ?>">
		Launch demo modal
	</button> -->
  */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Language\Text;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
	$wa->useScript('bootstrap.modal');

$modId = 'modal' . $module->id;
?>
<script type="text/javascript">
	document.addEventListener('DOMContentLoaded', () => {
		// Erstes Modal nach 1,5 Sekunden öffnen
		setTimeout(() => {
			const my<?php echo $modId; ?> = new bootstrap.Modal(document.getElementById('<?php echo $modId; ?>'));
			my<?php echo $modId; ?>.show();
		}, 4000);

		// Zweites Modal nach 4 Sekunden öffnen
//		setTimeout(() => {
//			const modal2 = new bootstrap.Modal(document.getElementById('modalZwei'));
//			modal2.show();
//		}, 4000);
	});

//    window.onload = () => {
//      const my<?php echo $modId; ?> = new bootstrap.Modal('#<?php echo $modId; ?>');
//      my<?php echo $modId; ?>.show();
//    }
</script>

<div id="<?php echo $modId; ?>" class="<?php echo $module->id; ?> modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <?php if($module->showtitle){ ?>
		 <h1 class="modal-title fs-3" id="<?php echo $modId; ?>"><?php echo $module->title; ?></h1>
		<?php } ?>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo $module->content; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-warning" data-bs-dismiss="modal"><?php echo TEXT::_('JCLOSE'); ?></button>
      </div>
    </div>
  </div>
</div>
