<?php
 /**
  * Joe Troppmair
  * https://stackoverflow.com/questions/69534538/bootstrap-5-modal-open-on-page-load
  * 
  * Button
  */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Language\Text;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
	$wa->useScript('bootstrap.modal');

$modId = 'modal' . $module->id;
?>

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#<?php echo $modId; ?>">
	<?php echo TEXT::_('JOPEN'); ?>
</button>

<div id="<?php echo $modId; ?>" class="<?php echo $module->id; ?> modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-3" id="<?php echo $modId; ?>"><?php echo $module->title; ?></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo $module->content; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo TEXT::_('JCLOSE'); ?></button>
        <!--a href="buchen" type="button" class="btn btn-warning">Da will ich hin - sofort buchen</a-->
      </div>
    </div>
  </div>
</div>
