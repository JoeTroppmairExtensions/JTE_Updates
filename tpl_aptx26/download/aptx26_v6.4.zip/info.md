*==========================================================*
|                                                          |
|  (C) JoeTroppmairExtensions 2026       JJ TTTTTT EEEEEE  |
|                                        JJ   TT   EE      |
|      Joe Troppmair                     JJ   TT   EEEE    |
|      www.troppmair.com             JJ  JJ   TT   EE      |
|                                     JJJJ    TT   EEEEEE  |
|      MOD_CAROUSEL_IMAGES_SLIDER                          |
|                                                          |
*==========================================================*

++++++++++++++++++++    Vorgaben    ++++++++++++++++++++

# 01.06.2025
	https://www.silva-apartments.com/
	
	1. https://stackoverflow.com/questions/36447725/creating-a-responsive-divider-vertical-horizontal-in-bootstrap
		=> col divider	

	Sprachschluessel fuer XML-Reiter:
		=> COM_TEMPLATES_BS5FRAMEWORK_FIELDSET_LABEL 	Bootstrap Framework

	2. https://www.youtube.com/watch?v=71qOoUvL37U
		=> Menü 2 Spalten mit BS5 siehe Footer-Menü


++++++++++++++++    noch zu erledigen    ++++++++++++++++
# 16.06.2025
   images/ ev. entfernen => auch aus XML!
   language/ en-GB.sys.ini Sprachschluessel für XML erzeugen und testen
	
   CookieConsent
      Test und Einbau von ??? keine Ahnung ???
	
   template.xml                            => weitere Optionen, Sprachschluessel
   includes/ params.php                    => nicht benötigte Zeilen aussortieren und CookieConsent aktivieren/entfernen, ev. über XML ansteuern
   includes/ footer.php                    => mit aktueller Gestaltung Position footermenu obsolet

   html/mod_menu jteFooterMenu.php         => Darstellung von "bi bi-arrow-right-short" funktioniert nur bei Alias Link, es muss derzeit die "CSS-Klasse für Link"
                                              zweckentfremdet werden. Unterschied in der HTML-Ausgabe noch nicht geprüft.
   html/mod_carousel_images defaultDIV.php => ev. neu benennen
	
   CSS
      13 CSS-Dateien                      => Sortierung und nicht benötigte Einträge jedenfalls entfernen!
      Bootstrap-Icons                     => Update auf Version
      Footer-Nav => :hover ohne Unterstreichung => gleich wie "active"
	
   JS
      fslightbox.js                       => 1. Versuche am 15.06.2025 unter Joomla! fuehren ins Leere, ev. als Blank-HTML testen
      cookieconsent-init.js               => siehe Pkt. 2 vom 16.06.2025


# 16.06.2025
   includes/ ma-consent.php entfernt.


# 17.06.2025	
   JS
      templates.js                         => da leer, in der params.php auskommentiert, enthält noch div. Test-Scripts, bzw. Hinweise zur Auslagerung
	
   Template Layouts /html/
      com_content/article tabs.php & tabs_links.php =>	!STABLE! Inhalt "Buchungsbedingungen"
      mod_carousel_images defaultDIV.php           	=> !STABLE! für Slide-Galerie auf Position "startslider"
      mod_custom    bsmodal.php                     => !STABLE! "on load" Modal
                    carouselmodal.php               => !ALPHA!	 wie oben, in Entwicklung
                    scrollbutton.php                => !STABLE! Modul Scrollbutton auf Pos. "startslider"
                    webcam.php                      => !ALPHA!  in Entwicklung
                    webcammodal.php                 => !ALPHA! in Entwicklung
      mod_menu      jteBS5-2rows.php                => Hauptmenü-Layout auf #offcanvas
                    jteFooterMenu.php               => FooterMenü-Layout, ohne Position - wird als Modul in Footer-Modul geladen, 2reihig
                    Standard-Vorlage default.php    => Topbar-Menü-Layout
                nicht verwendet, ev. noch brauchbar
                    jteDefault.php
                    jteBS5-default.php
                    jteFooterMenuLogo.php
                    jteFooterMenuLogoCollapse.php   => alle davon noch weiterentwickeln oder entfernen
      mod_random_image      divbackground.php       => 
                            bydate.php              => !ALPHA!  Vorversion für bymenuitemid.php
                            bymenuitemid.php        => !STABLE! Weiterentwicklung gewuenscht für Default-Image


# 23.06.2025
   includes/ basicmenu.php & offcanvas.php          => ID des Offcanvas umbenannt, DIV-Überschneidung bei XS & SM korrigiert, da Menübutton nur noch zu 1/3 Drittel klickbar
   Ordner Hilfsdatei angelegt                       => BS5 Strukturen für JCE
   CSS
      general.css                                   => weitere Version für "Cards" vorbereitet
      buttons.css                                   => Basicmenü Buttons nun mit runden Ecken, wg. DIV-Ueberschneidung Buttons nochmals verkleinert
      menu.css                                      => Sprachwahl nun mit runden Ecken



# Version 6.1 - 20.09.2026
  * Welche HTML-Overrides werden im APTX26-Template wirklich verwendet?

	com_content/article
		/- tabs.php             OK - Buchungsbedingungen + Anfrage
		/- tabs_links.php       entfernt, nicht notwendig
		
	mod_carousel_images
		/- startsliderJ6.php    OK - Startslider-Modul, ev. ins Modul selbst verbauen
		/- morerowsJ6.php       OK - Slider Kulinarik + Slider Aktiv-im-Zillertal, ev. ins Modul selbst verbauen	
									 Slider Sauna + Slider ApTx Kulinarik über die Modul-Default

	mod_custom
		/- bsmodal.php          OK - Buchungsinformationssystem OFFLINE
		/- consenty.php         OK - Cookie-Consent
		/- teaser.php           OK - Teaser, Position startslider
		/- scrollbutton.php     OK - Button Scroll, Position startslider
									 Footer, Holiday-Check, Das Kleingedruckte, EB Custom Quicksearch über Modul-Default

	mod_menu
		/- jteFooterMenu.php    OK - Footer-Menü
		/- jteBS5-offcanvas.php OK - Haupt Menü
		/- jteDefault.php       OK - Basic-Menü :: inkl. Folgedateien _component.php, _url.php
		
	mod_random_image
		/- bymenuitemid.php     OK - Bild by ItemID => aus images/flexheader
                                     Logo Overlay Offcanvas über Modul-Default
									 
	mod_webcams
		/- aptx26-card-consenty.php OK - Webcams-Darstellung


# Version 6.3 - 26.09.2026
 ** Update-Routine via script.php
	- bei Update werden Dateien, die nicht in der XML definiert sind, entfernt,
	  um den Code sauber zu halten
	- geschuetzte Dateien und Verzeichnisse moeglich, zB bereits definiert: 'tmpl/jte-entwicklung'

 ** templateDetails.XML
    - Anpassungen bzgl. Einbindung von JS als Option realisiert

 **	Sprachdateien zur XML angepasst
 
 ** html/mod_carousel_images
    - Template-Overrides entfernt, werden aus Original-Modul verwendet
 
 ** Zwingend notwendige CSS-Dateien:
    - template.css => mit @import 4 Dateien:
	    general.css,
		slide-admin.css,
		buttons.css,
		menu.css
	- bootstrap-icons.min.css
	- easybooking.cc => Einbindung ueber includes/eb/...php; Datei wird fuer mehrere Komponenten verwendet
	- teasar.css => Einbindung ueer tmpl/mod_custom/teaser.php > joomla.asset.json
	
 ** Entfernte CSS-Dateien:
	- start.css
	- cookieconsent.css => eine Datei eines nie verwendeten CC-Systems

 ** Zwingend notwendige JS-Dateien:
    - consenty.js => Consenty-Modul
	- float-panel.js => Verhalten des Contents beim Laden (von links "einfahren")
	
 ** Entfernte JS-Dateien:
	- template.js
	- fslightbox.js => nie verwendet
	
# Version 6.4 - 02.10.2026
 ** Consenty:
    es wurden bislang immer 2 Cookies "cc-show" gesetzt, 1. aus html/mod_custom/consenty.php, 2. aus includes/head.php

    - Entfernung des PHP-Teils in der head.php um das Cookie zu setzen
	- Anpassungen in der consenty.php im <script> Segment um das Modal trotzdem nur 1x erscheinen zu lassen
	- abgelehnte Consents: root/includes/consenty/cc_button.php ins Template verschoben, entsprechende Anpassungen für Easybooking/Bewertungen/Leaflet notwendig!

 ** Modals:
    Modal-Overrides erstellt, um damit ev. ein eigenen Modul zu realisieren:
    - bs5-modal-buttonopener
    - bs5-modal-selfopener
	- bs5-modal-selfopener-8s mit zeitversetzter Öffnungszeit