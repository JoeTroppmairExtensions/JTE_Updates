<?php
/**
 * @package    Consenty
 * @author     Joe
 */

defined('_JEXEC') or die;
use Joomla\CMS\Language\Text;
?>

<template consenty-if="!<?php echo $consenty; ?>">
	<div class="cc-bg pt-5">
		<p class="fs-3 ms-5 pb-2">
			<?php echo Text::_('CC_INFO_BLOCKEDCONTENT'); ?>
		</p>
		<p class="text-center">
			<button type="button" class="btn btn-danger btn-lg" consenty-allow="<?php echo $consenty; ?>"><?php echo Text::_('CC_ALLOW_CONTENT'); ?></button>
		</p>
		<p class="text-end me-5 pb-2">
			<a href="<?php echo Text::_('CC_GOTO_GPDRLINK'); ?>" class=""><?php echo Text::_('CC_GOTO_GPDR'); ?></a>
		</p>
	</div>
</template>