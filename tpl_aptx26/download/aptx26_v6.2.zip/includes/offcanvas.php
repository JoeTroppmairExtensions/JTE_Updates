<?php
/*------------------------------------------------------------------------
# von Joe Troppmair
# Website https://www.troppmair.com
-------------------------------------------------------------------------*/

// no direct access
	defined('_JEXEC') or die;
	use Joomla\CMS\Factory;
	use Joomla\CMS\Language\Text;
	
	$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
	$wa->useScript('bootstrap.offcanvas');
?>

<div class="offcanvas offcanvas-end w-fullwidth" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
  <div class="offcanvas-header">
	<h5 class="offcanvas-title" id="offcanvasMenuLabel"><?php echo Text::_('TPL_MENU'); ?></h5>
	<div id="bs5lg" class="d-md-none"><jdoc:include type="modules" name="language" /></div>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
	<div class="row">
	<div class="mx-auto col-md-10 col-lg-8 col-xxl-6">
	<nav class="navbar bg-body-tertiary">
	<div class="col-12 order-1 order-md-0 col-md-6 grid-divider2">
		<div class="row">
			<div class="col-6" style="position: absolute; top: 3%; left: 1%;">
				<div id="bs5lg" class="d-none d-md-block"><jdoc:include type="modules" name="language" /></div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-8 col-md-12 d-flex mx-auto my-auto justify-content-center">
				<a href="/" class="text-center"><img src="images/logo/logo_grau.png" alt="Logo" class="logo-img mt-2 mt-md-0" /></a>
			</div>
		</div>
	</div>
	<div class="col-12 col-md-6 d-flex mx-auto my-auto justify-content-center grid-divider1 mb-2 mb-md-0">  

		<jdoc:include type="modules" name="offcanvas" style="html5"/>
		
		<?php #include('cards.php'); ?>
		
		<jdoc:include type="modules" name="NO-menu" style="html5" />
		<jdoc:include type="modules" name="NO-footermenu" style="html5" />

	</div>
	</nav>
	</div>
	</div>
  </div>
</div>