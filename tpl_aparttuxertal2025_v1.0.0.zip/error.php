<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.aptx25
 *
 * @copyright   (C) 2024 Joe Troppmair <https://www.troppmair.com>
 
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;


?>
<div class="container=>
<jdoc:include type="message" />
</div>