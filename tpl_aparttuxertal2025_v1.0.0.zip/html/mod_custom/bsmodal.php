<?php
 /**
  * https://ghsvs.de/programmierer-schnipsel/joomla/315-joomla-modul-override-fuer-einbinden-eigener-codes
  */

defined('_JEXEC') or die;
// Bootstrap-Modul:
	JHtml::_('bootstrap.modal');
	JHtml::_('jquery.framework');
  
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

$modId = 'modal' . $module->id;
#$aktuellerSeitenPfad = JUri::getInstance()->getPath();
?>

<!-- Button trigger modal
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#<?php echo $modId; ?>">
  Launch demo modal
</button> -->
<script>
	$(document).ready(function(){
			$("#<?php echo $modId; ?>").modal('show');
		});
</script>

<!-- Modal -->
<div id="<?php echo $modId; ?>" class="<?php echo $module->id; ?> modal fade" tabindex="-1" aria-labelledby="<?php echo $modId; ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-3" id="<?php echo $modId; ?>"><?php echo $module->title; ?></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php echo $module->content; ?>
      </div>
      <div class="modal-footer">
        <!--button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button -->
        <a href="buchen" type="button" class="btn btn-warning">Da will ich hin - sofort buchen</a>
      </div>
    </div>
  </div>
</div>
