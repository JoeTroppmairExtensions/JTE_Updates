<?php
/*------------------------------------------------------------------------
# von Joe Troppmair
# Website https://www.troppmair.com
-------------------------------------------------------------------------*/

// no direct access
	defined('_JEXEC') or die;
// Joomla Textklasse "Text::_('TPL_MENU');", wenn aus "JText::_('...');" notwendig
	#use Joomla\CMS\Language\Text;
// Bootstrap-Modul:
	JHtml::_('bootstrap.offcanvas');
	JHtml::_('bootstrap.dropdown');

?>
<?php 
	if ( $this->params->get('offcanvasmenu') == 1 ) {
?>
		<nav id="offcanvasbutton"><a class="btn btn-xs btn-secondary" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button" aria-controls="offcanvasExample"><?php echo JText::_('TPL_MENU'); ?> ☰</a></nav>
<?php } ?>
<div class="offcanvas offcanvas-end w-67" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
	<h5 class="offcanvas-title" id="offcanvasExampleLabel"><?php echo JText::_('TPL_MENU'); ?></h5>
	<jdoc:include type="modules" name="language" />
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <jdoc:include type="modules" name="offcanvas" style="html5"/>
	
	<?php include('cards.php'); ?>
	
	<jdoc:include type="modules" name="menu" style="html5" />
	<jdoc:include type="modules" name="footermenu" style="html5" />
  </div>
</div>