<!-- ***** TOPBAR ***** -->

<?php defined('_JEXEC') or die; ?>

<?php if ( $this->countModules('menu') ) : ?>
	<div id="menu"><jdoc:include type="modules" name="menu" style="html5" /></div>
<?php endif; ?>
<?php if ( $this->countModules('startslider') ) : ?>
	<div id="bg"><jdoc:include type="modules" name="startslider" style="html5" /></div>
<?php endif; ?>