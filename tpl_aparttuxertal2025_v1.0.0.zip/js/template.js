/*! Joe Troppmair Joomla! Templates (C) 2021 */

/*! Modal ID 123 laden
	$(window).on('load', function() {
		$('#modal123').modal('show');
    });
AUSGELAGERT in das Modul-Template bsmodal.php */

/*! ###################################
	ab hier: JQUERY notwendig:			*/

/*! Offcanvas Menuebutton erweitern */
	jQuery(function($) {
		$('ul#easybookingmenu li a[href="#offcanvasExample"]').attr('data-bs-toggle','offcanvas');
	});
