<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_webcams
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

defined('_JEXEC') or die;
JHtml::_('bootstrap.modal');

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
$modId = 'webcam' . $module->id;
}
#$sliderID = $params->get('sliderID', 'default');
#$sliderStyle = $params->get('sliderStyle', 'default');
#$sliderNavControl = $params->get('sliderNavControl', 'default');
#$sliderIndicator = $params->get('sliderIndicator', 'default');
#$sliderDarkControl = $params->get('sliderDarkControl', 'default');
#$sliderCaptionControl = $params->get('sliderCaptionControl', 'default');

#$introimg = $params->get('introimg');
#$modId = 'webcam' . $module->id;

// Debug
#echo $folder;
# echo $type;
# echo $params->get('type', 'jpg');
#	<h3><?php echo JText::_('CAPTION_TITLE_' .strtoupper(pathinfo($item->name), PATHINFO_FILENAME). '.' .$params->get('type', 'jpg'). '');
?>

<p> TEST </p>