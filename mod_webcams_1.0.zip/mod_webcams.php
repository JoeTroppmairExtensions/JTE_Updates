<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_webcams
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

\defined('_JEXEC') or die;
use Joomla\CMS\Helper\ModuleHelper;
use Troppmair\Module\Webcams\Site\Helper\WebcamsHelper;

#$folder = CarouselImagesHelper::getFolder($params);
#$images = CarouselImagesHelper::getImages($params, $folder);
#$image  = CarouselImagesHelper::getRandomImage($params, $images);

require ModuleHelper::getLayoutPath('mod_webcams', $params->get('layout', 'default'));
?>

