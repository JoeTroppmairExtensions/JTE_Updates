<?php
/**
 * @package    mod_webcams
 * @author     Joe
 */

defined('_JEXEC') or die;

#use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
?>
<div id="myNav" class="overlay">
	<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times; <span class="closebtn-span"><?php echo TEXT::_('TPL_JOE_OFFCANVASMENU_CLOSE'); ?></span></a>
	
	<div class="overlay-content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3">
					<jdoc:include type="modules" name="off-canvas-1" style=""/>
				</div>
				<div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3">
					<jdoc:include type="modules" name="off-canvas-2" style=""/>
				</div>
				<div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3">
					<jdoc:include type="modules" name="off-canvas-3" style=""/>
				</div>
				<div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3">
					<jdoc:include type="modules" name="off-canvas-4" style=""/>
				</div>
			</div>
		</div>
	</div>
</div>