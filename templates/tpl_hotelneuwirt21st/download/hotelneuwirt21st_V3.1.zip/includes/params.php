<?php
/*------------------------------------------------------------------------
# von Joe Troppmair
# Website https://www.troppmair.com
-------------------------------------------------------------------------*/

	defined('_JEXEC') or die;
	use Joomla\CMS\Factory;
	
	// Anzeige Meta-Generator Joomla ausschalten:
		$this->setGenerator(null);
	
	// Template-Einstellungen holen
	#	$params = Factory::getApplication()->getTemplate(true)->params;
	#	$app = Factory::getApplication();
	#	$doc = Factory::getDocument();
	
	// Spalten-Breiten
	$leftcolgrid = ($this->countModules('left') == 0) ? 0 :
	$this->params->get('leftColumnWidth', 3);
	$rightcolgrid = ($this->countModules('right') == 0) ? 0 :
	$this->params->get('rightColumnWidth', 3);

	// Zuladen von CSS und JS nach J!6-Vorgaben:
	$doc = Factory::getApplication()->getDocument();
	$wa  = $doc->getWebAssetManager();

	// Bootstrap 4
	$wa->useStyle('bootstrap4');
	$wa->useStyle('jquery-css');
	$wa->useStyle('template-css');
	$wa->useStyle('offcanvas-css');
	$wa->useStyle('sidebar-css');

	$wa->useScript('bootstrap4-js');
	$wa->useScript('jquery-js');
	$wa->useScript('template-js');
	
	// Variables
	#	$headdata = $doc->getHeadData();
	#	$menu = $app->getMenu();
	#	$active = $app->getMenu()->getActive();
	#	$pageclass = $params->get('pageclass_sfx');
	$tpath = $this->baseurl . '/templates/' . $this->template;

	// Parameter
	$fontawesome = $this->params->get('fontawesome');

	// Add stylesheets
	if ($fontawesome == 1){
		$wa->useStyle('fontawesome-icons');
	}