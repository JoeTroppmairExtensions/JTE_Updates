<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_carousel_images
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

/** Nr. 1 ###    aus Original - funktioniert:

	use Joomla\Module\RandomImage\Site\Helper\RandomImageHelper;

	$link   = $params->get('link');
	$folder = RandomImageHelper::getFolder($params);
	$images = RandomImageHelper::getImages($params, $folder);
	$image  = RandomImageHelper::getRandomImage($params, $images);

*/

/** Nr. 2 ###    eigene Klasse - funktioniert: */
use Troppmair\Module\CarouselImages\Site\Helper\CarouselImagesHelper;

$link   = $params->get('link');
$folder = CarouselImagesHelper::getFolder($params);
$images = CarouselImagesHelper::getImages($params, $folder);
$image  = CarouselImagesHelper::getRandomImage($params, $images);


require ModuleHelper::getLayoutPath('mod_carousel_images', $params->get('layout', 'default'));
