<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_carousel_images
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();

$wa->useScript('bootstrap.carousel');
#$wa->useStyle('standard.css');
$wa->useStyle('carousel-images-css'); //kommt derzeit aus der Template joomla.asset.json => jene vom Modul will noch nicht

use Troppmair\Module\CarouselImages\Site\Helper\CarouselImagesHelper;

$link   = $params->get('link');
$folder = CarouselImagesHelper::getFolder($params);
$images = CarouselImagesHelper::getImages($params, $folder);
$image  = CarouselImagesHelper::getRandomImage($params, $images);

require ModuleHelper::getLayoutPath('mod_carousel_images', $params->get('layout', 'default'));
?>