<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_carousel_images
 *
 * Service from: https://gist.github.com/EdgarPateno/fd118fb55334859b9462a9ac4adc4216
 *
 * @copyright   (C) 2024 Joe Troppmair
 * @license     ...
 */

defined('_JEXEC') or die;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
$wa = Factory::getApplication()
    ->getDocument()
    ->getWebAssetManager();

$wa->useScript('bootstrap.carousel');
$wa->useStyle('carousel-images-css');

if (empty($images)) {
    echo Text::_('MOD_RANDOM_IMAGE_NO_IMAGES');
    return;
}
#$doc->addStyleSheet('modules/mod_carousel_images/css/moreRows.css');
#$sliderID = $params->get('sliderID', 'default');
$sliderStyle = $params->get('sliderStyle', 'default');
$sliderNavControl = $params->get('sliderNavControl', 'default');
$sliderIndicator = $params->get('sliderIndicator', 'default');
$sliderDarkControl = $params->get('sliderDarkControl', 'default');
$sliderCaptionControl = $params->get('sliderCaptionControl', 'default');

// Debug
#echo $folder;
# echo $type;
# echo $params->get('type', 'jpg');
#	<h3><?php echo JText::_('CAPTION_TITLE_' .strtoupper(pathinfo($item->name), PATHINFO_FILENAME). '.' .$params->get('type', 'jpg'). '');
?>
<head>
  <link rel="stylesheet" href="modules/mod_carousel_images/css/moreRows.css">
</head>
<div class="row mx-auto my-4 justify-content-center">
<div id="multipleRows" class="carousel <?php echo $sliderStyle; ?> <?php echo $sliderDarkControl; ?>" data-bs-ride="carousel">
	
	<div class="carousel-inner">
		<?php for ($i = 0, $n = count($images); $i < $n; $i ++) : ?>
			<?php $item = $images[$i]; ?>
				<?php if ($i == 0){?>
					<div class="carousel-item <?php echo 'active';  ?>" >
						<div class="col-12 col-md-6 col-xl-4">
						<div class="mx-1"><?php echo HTMLHelper::_('image', $item->folder . '/' . htmlspecialchars($item->name, ENT_COMPAT, 'UTF-8'), ''); ?></div>
							<?php if ($sliderCaptionControl == 1) : ?>
								<div class="carousel-caption d-none d-md-block">
									<h3><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_HX'); ?></h3>
									<p><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_TX'); ?></p>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php } else { ?>
					<div class="carousel-item" >
						<div class="col-12 col-md-6 col-xl-4">
							<div class="mx-1"><?php echo HTMLHelper::_('image', $item->folder . '/' . htmlspecialchars($item->name, ENT_COMPAT, 'UTF-8'), ''); ?></div>
							<?php if ($n > 1 && $sliderCaptionControl == 1) : ?>
								<div class="carousel-caption d-none d-md-block">								
									<h3><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_HX'); ?></h3>
									<p><?php echo JText::_('MOD_CAROUSEL_' .strtoupper($item->name). '_TX'); ?></p>
								</div>
							<?php endif; ?>
							
						</div>
					</div>
				<?php } ?>
		<?php endfor; ?>
	</div>

	<?php if ($n > 1 && $sliderIndicator == 1) : ?>
		<div class="carousel-indicators">
		<?php for ($i = 0, $n = count($images); $i < $n; $i ++) : ?>
			<?php if ($i == 0){?>
			<button type="button" data-bs-target="#multipleRows" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
			<?php } else { ?>
			<button type="button" data-bs-target="#multipleRows" data-bs-slide-to="<?php echo $i; ?>" aria-label="Slide 2"></button>
			<?php } ?>
		<?php endfor; ?>
		</div>
	<?php endif; ?>	

	<?php if ($n > 1 && $sliderNavControl == 1) : ?>
		<button class="carousel-control-prev" type="button" data-bs-target="#multipleRows" data-bs-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		</button>
		<button class="carousel-control-next" type="button" data-bs-target="#multipleRows" data-bs-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
		</button>
	<?php endif; ?>
</div>
</div>

<script>
let items = document.querySelectorAll('#multipleRows .carousel-item')
	
	let vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
	//alert(vw);
	if (vw <= 1199) {
		rows = 2;
	}
	else if (vw >= 1200) {
		rows = 3;
	}
	
	items.forEach((el) => {
		const minPerSlide = rows
		let next = el.nextElementSibling
		for (var i=1; i<minPerSlide; i++) {
			if (!next) {
           // wrap carousel by using first child
           next = items[0]
       }
       let cloneChild = next.cloneNode(true)
       el.appendChild(cloneChild.children[0])
       next = next.nextElementSibling
    }
})
</script>